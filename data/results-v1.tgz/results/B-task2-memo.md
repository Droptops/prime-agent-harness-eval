# Memo: Do not enable auto-refine by default for our 20 engineers

**To:** Engineering Director
**Re:** `packages/coding-agent/src/core/refinement/refinement.ts`
**Recommendation:** ship auto-refine **opt-in**. Note this is an active change — the code already defaults to on (`settings-manager.ts:839`, `enabled ?? true`).

## 1. The cadence is frequent and unattended

Auto-refine has two triggers, `"turn_interval" | "compact"` (`refinement.ts:110`). Defaults are 25 assistant turns and every compaction, throttled by a 20-minute cooldown (`settings-manager.ts:23–28`, enforced at `agent-session.ts:2361`, `2366`). Compaction-triggered refinement fires precisely when a session is already long and slow, and the apply phase disconnects from the agent (`agent-session.ts:7776`), so it lands as latency on the interactive loop for all 20 people.

## 2. The cost per checkpoint is two LLM calls, both large

Each checkpoint runs a review call — 40,000 chars of trajectory (`refinement.ts:960`) at up to 4,096 output tokens (`194`, `985`) — and, if approved, a full refine call: 80,000 chars of trajectory (`892`) plus the harness overview (40 entries/kind, `527–543`) and 20 prior refinements (`553`), at up to **32,000 output tokens** (`193`, `919`). At 3 checkpoints/hour/session, ~4 active hours/day, 20 engineers, that is ~240 checkpoints/day and roughly 7M+ input tokens/day before output — a headcount-scaling bill.

## 3. The benefit does not scale with headcount, because the default scope is local

The scope default is `"local"` at `refinement.ts:768` and `1015`, reinforced by the policy text at `141`, `177`, and `895`. Auto-refine's generated instructions go further: *"Do not promote anything global unless explicitly requested"* (`agent-session.ts:977`). Local state lives in the per-session artifact dir (`refinement.ts:273–275`) and is deliberately excluded from the shared rollback log (`369–379`). So we would pay 20× for 20 private harnesses that never merge, never compound, and die with the session.

Rollback is worse for exactly the writes we would be generating: only global results are appended to `refinements.jsonl` (`374–379`), while local ones are recoverable solely through the `harnessStatePath` recorded in the session log (`369–373`).

## 4. Quality controls are thin

`validateEdit` (`664–705`) checks structure only — no dedup, no semantics. Ids are slugged from titles (`715`, `224–232`), so near-duplicate titles silently fail as "entry already exists" (`751–753`). There is **no eviction anywhere in the file**, yet the prompt overview shows only 6 entries per kind (`26`, `497–500`): growth past that point is pure token tax with zero recall.

## Proposal

Set `autoRefine.enabled: false` in the team template; pilot with 3–4 volunteers; keep manual `/refine`. Revisit once eviction and human review of global promotions exist.
